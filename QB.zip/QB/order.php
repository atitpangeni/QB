<!-- order.php -->
<?php
// Assuming you have a database connection file (db_connection.php)
include 'db_connection.php';

// Check if the restaurant ID is provided in the URL
if (isset($_GET['rs_id'])) {
    $restaurant_id = $_GET['rs_id'];

    $conn = openDatabaseConnection(); // Use your database connection function

    // Fetch details for the selected restaurant (adjust column names as needed)
    $sql = "SELECT * FROM restaurant WHERE rs_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $restaurant_id);
    $stmt->execute();

    // Fetch the restaurant details
    $result = $stmt->get_result();
    $restaurant = $result->fetch_assoc();

    // Display restaurant details and ordering form
    if ($restaurant) {
        echo '<h1>' . htmlspecialchars($restaurant['title']) . '</h1>';
        echo '<p>' . htmlspecialchars($restaurant['address']) . '</p>';
        // Add other details as needed
        echo '<a href="checkout.php?id=' . htmlspecialchars($row['rs_id']) . '">Order Now</a>';
        // Add your ordering form here

    } else {
        echo 'Restaurant not found.';
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: index.php");
    exit();
}
?>
