 


<?php
// Assuming you have a database connection file (db_connection.php)
include 'db_connection.php';

if (isset($_GET['query'])) {
    $search_query = $_GET['query'];

    $conn = openDatabaseConnection(); // Use your database connection function

    // Perform a search query (adjust column names as needed)
    $sql = "SELECT * FROM dishes WHERE title LIKE ?";
    $stmt = $conn->prepare($sql);

    // Bind the parameter and execute the query
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();

    // Fetch the results
    $result = $stmt->get_result();

    // Display the search results with links to the ordering page
    while ($row = $result->fetch_assoc()) {
        echo '<div>';
        echo '<img src="admin/Res_img/dishes/'. htmlspecialchars($row['img']) . '" style="max-width: 100px; max-height: 100px;">';
        echo '<h2>'. htmlspecialchars($row ['title']) . '</h2>';
        echo '<h6>'. htmlspecialchars($row ['rs_id']) . '</h6>';
        echo '<p>Rs. ' . htmlspecialchars($row['price']) . '</p>';
        echo '<a href="dishes.php?id=' . htmlspecialchars($row['rs_id']) . '">Order Now</a>';
        echo '</div>';
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: index.php");
    exit();
}
?>

						
