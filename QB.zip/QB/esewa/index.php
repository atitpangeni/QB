<?php
// esewa/index.php

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the values from the form
    $productId = isset($_POST['id']) ? $_POST['id'] : '';
    $itemTotal = isset($_POST['total']) ? $_POST['total'] : '';

    // Now you can use $productId and $itemTotal as needed
    // For example, you can echo them or use them in further processing
    echo "Product ID: " . $productId . "<br>";
    echo "Item Total: " . $itemTotal . "<br>";

    // Your additional processing logic goes here
}
?>
<div class="col-md-6">
							<h3>Pay With</h3>
							<ul class="list-group">
								<li class="list-group-item">
									<form action="https://uat.esewa.com.np/epay/main" method="POST">
										<input value="<?php echo $itemTotal;?>" name="tAmt" type="hidden">
										<input value="<?php echo $itemTotal;?>" name="amt" type="hidden">
										<input value="0" name="txAmt" type="hidden">
										<input value="0" name="psc" type="hidden">
										<input value="0" name="pdc" type="hidden">
										<input value="epay_payment" name="scd" type="hidden">
										<input value="<?php echo $productId;?>" name="pid" type="hidden">
										<input value="http://localhost/qb/esewa/esewa_payment_success.php" type="hidden" name="su">
										<input value="http://localhost/qb/esewa/esewa_payment_failed.php" type="hidden" name="fu">
										<input type="image" img src="../images/esewa.png">
										</li>
									</ul>
								</div>
								
							</div>
						</div>