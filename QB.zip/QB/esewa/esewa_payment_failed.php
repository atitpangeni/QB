<?php 
echo "Payment failed! Try again......";
?>