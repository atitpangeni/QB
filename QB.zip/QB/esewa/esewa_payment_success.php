<html>
<?php
echo "Thank you for payment...";

?>
<body>
<a href="C:\xampp\htdocs\qb\index.php"> home </a></body>
</html>