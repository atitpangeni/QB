-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2024 at 02:09 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin@mail.com', '', '2024-01-30 11:04:53'),
(2, 'sital', 'e10adc3949ba59abbe56e057f20f883e', 'sital@gmail.com', '', '2024-02-02 06:13:00'),
(3, 'atit', '2926a5d206fffe75b2e36fbd1b245758', 'atetpangeni@gmail.com', '', '2024-02-03 08:50:49'),
(4, 'amit', 'e10adc3949ba59abbe56e057f20f883e', 'amit@gmail.com', '', '2024-02-03 08:47:38'),
(5, 'bijaya', 'e10adc3949ba59abbe56e057f20f883e', 'bijaya@gmail.com', '', '2024-02-04 15:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`) VALUES
(2, 3, 'Baked vegetables', ' Serve hot with freshly toasted garlic bread', '200.00', '65b9e182e5db9.png'),
(3, 2, 'chinese cuisine', 'family-style, with a variety of dishes placed in the center of the table and shared among everyone at the table.', '600.00', '65b9e1005899c.png'),
(4, 1, 'Stuffed Jacket Potatoes', 'Deep fry whole potatoes in oil for 8-10 minutes or coat each potato with little oil. Mix the onions, garlic, tomatoes and mushrooms. Add yoghurt, ginger, garlic, chillies, coriander', '8.00', '62908d393465b.jpg'),
(5, 2, 'Pink Spaghetti Gamberoni', 'Spaghetti with prawns in a fresh tomato sauce. This dish originates from Southern Italy and with the combination of prawns, garlic, chilli and pasta. Garnish each with remaining tablespoon parsley.', '21.00', '606d7491a9d13.jpg'),
(6, 2, 'Cheesy Mashed Potato', 'Deliciously Cheesy Mashed Potato. The ultimate mash for your Thanksgiving table or the perfect accompaniment to vegan sausage casserole. Everyone will love it\'s fluffy, cheesy.', '5.00', '606d74c416da5.jpg'),
(7, 2, 'Crispy Chicken Strips', 'Fried chicken strips, served with special honey mustard sauce.', '8.00', '606d74f6ecbbb.jpg'),
(8, 2, 'Lemon Grilled Chicken And Pasta', 'Marinated rosemary grilled chicken breast served with mashed potatoes and your choice of pasta.', '11.00', '606d752a209c3.jpg'),
(9, 3, 'Vegetable Fried Rice', 'Chinese rice wok with cabbage, beans, carrots, and spring onions.', '5.00', '606d7575798fb.jpg'),
(10, 3, 'Prawn Crackers', '12 pieces deep-fried prawn crackers', '7.00', '606d75a7e21ec.jpg'),
(11, 3, 'Spring Rolls', 'Lightly seasoned shredded cabbage, onion and carrots, wrapped in house made spring roll wrappers, deep fried to golden brown.', '6.00', '606d75ce105d0.jpg'),
(12, 3, 'Manchurian Chicken', 'Chicken pieces slow cooked with spring onions in our house made manchurian style sauce.', '11.00', '606d7600dc54c.jpg'),
(14, 1, 'stuffed potatoes', 'Serve immediately, garnish with sour cream, reserved bacon and chives.', '230.00', '65b9e02694903.png'),
(15, 1, 'paner steak', ' close-knit texture and possesses a sweetish-acidic-nutty flavor. ', '430.00', '65b9dfd7a59da.png'),
(16, 2, 'Momo', 'a dumpling made of all-purpose flour and filled with either meat or vegetables.', '210.00', '65b9de731b9ed.png'),
(17, 5, 'Asian cuisine', 'Every dish is cooked using a wide array of spices and condiments that helps bring out a distinct flavour.', '550.00', '65b9efd2ad8cf.png'),
(18, 5, 'Galze ham', 'Our perfectly roasted glazed ham recipes are ideal for feeding a crowd for a special occasion.', '550.00', '65b9f08dc5b1f.png'),
(19, 1, 'Thakali Khana', '\"Thakali Khana Set\" refers to a traditional meal set from the Thakali community, an indigenous group in the Mustang region of Nepal. Thakali cuisine is known for its simple yet flavorful dishes, and a Thakali Khana Set typ', '200.00', '65bf6b537f567.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remark`
--

INSERT INTO `remark` (`id`, `frm_id`, `status`, `remark`, `remarkDate`) VALUES
(1, 2, 'in process', 'none', '2022-05-01 05:17:49'),
(2, 3, 'in process', 'none', '2022-05-27 11:01:30'),
(3, 2, 'closed', 'thank you for your order!', '2022-05-27 11:11:41'),
(4, 3, 'closed', 'none', '2022-05-27 11:42:35'),
(5, 4, 'in process', 'none', '2022-05-27 11:42:55'),
(6, 1, 'rejected', 'none', '2022-05-27 11:43:26'),
(7, 7, 'in process', 'none', '2022-05-27 13:03:24'),
(8, 8, 'in process', 'none', '2022-05-27 13:03:38'),
(9, 9, 'rejected', 'thank you', '2022-05-27 13:03:53'),
(10, 7, 'closed', 'thank you for your ordering with us', '2022-05-27 13:04:33'),
(11, 8, 'closed', 'thanks ', '2022-05-27 13:05:24'),
(12, 5, 'closed', 'none', '2022-05-27 13:18:03'),
(13, 13, 'in process', 'ok', '2024-01-30 10:33:43'),
(14, 6, 'closed', 'deliver', '2024-01-30 10:34:06'),
(15, 14, 'in process', 'qwwer', '2024-01-31 09:29:49'),
(16, 15, 'rejected', 'ddsss', '2024-01-31 09:30:12'),
(17, 22, 'closed', 'ok', '2024-02-03 09:08:45'),
(18, 23, 'closed', 'ok', '2024-02-03 15:38:26'),
(19, 25, 'closed', '\r\n.', '2024-02-04 13:13:11');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`) VALUES
(1, 4, 'Hotel Gulmohar', 'gulmohar@mail.com', '056494814', 'www.gulmohar.com', '11am', '8pm', 'mon-sat', 'MC9V+G3 , Bharatpur', '65b9d4a61a8ed.png', '2024-01-31 05:03:34'),
(2, 1, 'Hotel Happy Home', 'happyhome@gmail.com', '9855050688', 'www.happyhome.com', '11am', '8pm', 'mon-sat', 'Bharatpur, Chitwan', '65b9d41015eba.png', '2024-01-31 05:01:04'),
(3, 3, 'Hotel Siraichhuli', 'hotelsiraichuli@mail.com', '1234567890', 'www.hotelsiraichuli.com', '6am', '8pm', '24hr-x7', '   Bharatpur Height, Chitwan   ', '65b9d14fc65b0.png', '2024-01-31 04:49:19'),
(5, 2, 'Central Palm', 'palm@gmail.com', '9761731052', 'http://centralpalms-hotel.com.np/', '12pm', '2am', '24hr-x7', 'MCV8+7JJ Central Palms Hotel, Bharatpur,  44207', '65b9d55fe172f.png', '2024-01-31 05:06:39');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`, `date`) VALUES
(1, 'Continental', '2022-05-27 08:07:35'),
(2, 'Italian', '2021-04-07 08:45:23'),
(3, 'Neplali', '2024-01-31 04:30:22'),
(4, 'Chinese', '2024-01-31 04:29:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(222) NOT NULL DEFAULT 1,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`) VALUES
(12, 'atitpangeni', 'Atit', 'Pangeni', 'atetpangeni@gmail.com', '9845056375', '2926a5d206fffe75b2e36fbd1b245758', 'bharatpur 5', 1, '2024-02-03 09:30:32');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_orders`
--

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(13, 7, 'Cheesy Mashed Potato', 1, '5.00', 'in process', '2024-01-30 10:33:43'),
(14, 9, 'Baked vegetables', 1, '200.00', 'in process', '2024-01-31 09:29:49'),
(15, 9, 'Vegetable Fried Rice', 1, '5.00', 'rejected', '2024-01-31 09:30:12'),
(16, 9, 'Prawn Crackers', 1, '7.00', NULL, '2024-01-31 09:27:47'),
(20, 8, 'chinese cuisine', 1, '600.00', NULL, '2024-02-01 06:01:45'),
(21, 8, 'Baked vegetables', 2, '200.00', NULL, '2024-02-01 10:54:30'),
(22, 8, 'chinese cuisine', 1, '600.00', 'closed', '2024-02-03 09:08:45'),
(23, 12, 'stuffed potatoes', 1, '230.00', 'closed', '2024-02-03 15:38:26'),
(24, 12, 'Thakali Khana', 1, '200.00', NULL, '2024-02-04 10:49:50'),
(25, 12, 'chinese cuisine', 1, '600.00', 'closed', '2024-02-04 13:13:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
